
using System;

namespace SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning
{
public enum EstadoPagoEnum { pendiente=1, aprovado=2, rechazado=3 };
}
