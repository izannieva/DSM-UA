
using System;

namespace SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning
{
public enum EstadoEnum { disponible=1, vendido=2, reservado=3, cancelado=4 };
}
