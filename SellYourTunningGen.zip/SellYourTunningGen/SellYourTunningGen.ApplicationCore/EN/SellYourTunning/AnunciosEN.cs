
using System;
// Definición clase AnunciosEN
namespace SellYourTunningGen.ApplicationCore.EN.SellYourTunning
{
public partial class AnunciosEN
{
/**
 *	Atributo pertenece
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> pertenece;



/**
 *	Atributo publica
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN publica;



/**
 *	Atributo pago
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pago;



/**
 *	Atributo vehiculo
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> vehiculo;



/**
 *	Atributo vehiculo_0
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN vehiculo_0;



/**
 *	Atributo idVehiculo
 */
private int idVehiculo;



/**
 *	Atributo titulo
 */
private string titulo;



/**
 *	Atributo fechaPublicacion
 */
private Nullable<DateTime> fechaPublicacion;



/**
 *	Atributo estado
 */
private SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum estado;



/**
 *	Atributo precioVenta
 */
private double precioVenta;



/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo destacado
 */
private bool destacado;






public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> Pertenece {
        get { return pertenece; } set { pertenece = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN Publica {
        get { return publica; } set { publica = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> Pago {
        get { return pago; } set { pago = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> Vehiculo {
        get { return vehiculo; } set { vehiculo = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN Vehiculo_0 {
        get { return vehiculo_0; } set { vehiculo_0 = value;  }
}



public virtual int IdVehiculo {
        get { return idVehiculo; } set { idVehiculo = value;  }
}



public virtual string Titulo {
        get { return titulo; } set { titulo = value;  }
}



public virtual Nullable<DateTime> FechaPublicacion {
        get { return fechaPublicacion; } set { fechaPublicacion = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum Estado {
        get { return estado; } set { estado = value;  }
}



public virtual double PrecioVenta {
        get { return precioVenta; } set { precioVenta = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual bool Destacado {
        get { return destacado; } set { destacado = value;  }
}





public AnunciosEN()
{
        pertenece = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN>();
        pago = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN>();
        vehiculo = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN>();
}



public AnunciosEN(int id, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> pertenece, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN publica, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pago, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> vehiculo, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN vehiculo_0, int idVehiculo, string titulo, Nullable<DateTime> fechaPublicacion, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum estado, double precioVenta, bool destacado
                  )
{
        this.init (Id, pertenece, publica, pago, vehiculo, vehiculo_0, idVehiculo, titulo, fechaPublicacion, estado, precioVenta, destacado);
}


public AnunciosEN(AnunciosEN anuncios)
{
        this.init (anuncios.Id, anuncios.Pertenece, anuncios.Publica, anuncios.Pago, anuncios.Vehiculo, anuncios.Vehiculo_0, anuncios.IdVehiculo, anuncios.Titulo, anuncios.FechaPublicacion, anuncios.Estado, anuncios.PrecioVenta, anuncios.Destacado);
}

private void init (int id
                   , System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> pertenece, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN publica, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pago, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> vehiculo, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN vehiculo_0, int idVehiculo, string titulo, Nullable<DateTime> fechaPublicacion, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum estado, double precioVenta, bool destacado)
{
        this.Id = id;


        this.Pertenece = pertenece;

        this.Publica = publica;

        this.Pago = pago;

        this.Vehiculo = vehiculo;

        this.Vehiculo_0 = vehiculo_0;

        this.IdVehiculo = idVehiculo;

        this.Titulo = titulo;

        this.FechaPublicacion = fechaPublicacion;

        this.Estado = estado;

        this.PrecioVenta = precioVenta;

        this.Destacado = destacado;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        AnunciosEN t = obj as AnunciosEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
