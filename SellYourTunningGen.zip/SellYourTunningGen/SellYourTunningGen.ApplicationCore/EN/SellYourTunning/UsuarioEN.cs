
using System;
// Definición clase UsuarioEN
namespace SellYourTunningGen.ApplicationCore.EN.SellYourTunning
{
public partial class UsuarioEN
{
/**
 *	Atributo mensajes_enviados
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> mensajes_enviados;



/**
 *	Atributo mensajes_recibido
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> mensajes_recibido;



/**
 *	Atributo pertenece
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> pertenece;



/**
 *	Atributo pago
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pago;



/**
 *	Atributo idUsuario
 */
private int idUsuario;



/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo email
 */
private string email;



/**
 *	Atributo password
 */
private string password;



/**
 *	Atributo telefono
 */
private string telefono;



/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo pago_0
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN pago_0;






public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> Mensajes_enviados {
        get { return mensajes_enviados; } set { mensajes_enviados = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> Mensajes_recibido {
        get { return mensajes_recibido; } set { mensajes_recibido = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> Pertenece {
        get { return pertenece; } set { pertenece = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> Pago {
        get { return pago; } set { pago = value;  }
}



public virtual int IdUsuario {
        get { return idUsuario; } set { idUsuario = value;  }
}



public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual string Email {
        get { return email; } set { email = value;  }
}



public virtual string Password {
        get { return password; } set { password = value;  }
}



public virtual string Telefono {
        get { return telefono; } set { telefono = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN Pago_0 {
        get { return pago_0; } set { pago_0 = value;  }
}





public UsuarioEN()
{
        mensajes_enviados = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN>();
        mensajes_recibido = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN>();
        pertenece = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN>();
        pago = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN>();
}



public UsuarioEN(int id, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> mensajes_enviados, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> mensajes_recibido, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> pertenece, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pago, int idUsuario, string nombre, string email, string password, string telefono, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN pago_0
                 )
{
        this.init (Id, mensajes_enviados, mensajes_recibido, pertenece, pago, idUsuario, nombre, email, password, telefono, pago_0);
}


public UsuarioEN(UsuarioEN usuario)
{
        this.init (usuario.Id, usuario.Mensajes_enviados, usuario.Mensajes_recibido, usuario.Pertenece, usuario.Pago, usuario.IdUsuario, usuario.Nombre, usuario.Email, usuario.Password, usuario.Telefono, usuario.Pago_0);
}

private void init (int id
                   , System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> mensajes_enviados, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.MensajesEN> mensajes_recibido, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> pertenece, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pago, int idUsuario, string nombre, string email, string password, string telefono, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN pago_0)
{
        this.Id = id;


        this.Mensajes_enviados = mensajes_enviados;

        this.Mensajes_recibido = mensajes_recibido;

        this.Pertenece = pertenece;

        this.Pago = pago;

        this.IdUsuario = idUsuario;

        this.Nombre = nombre;

        this.Email = email;

        this.Password = password;

        this.Telefono = telefono;

        this.Pago_0 = pago_0;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        UsuarioEN t = obj as UsuarioEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
