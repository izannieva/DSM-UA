
using System;
// Definición clase VehiculoEN
namespace SellYourTunningGen.ApplicationCore.EN.SellYourTunning
{
public partial class VehiculoEN
{
/**
 *	Atributo categoria
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.CategoriaEN> categoria;



/**
 *	Atributo anuncio
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> anuncio;



/**
 *	Atributo anuncio_0
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> anuncio_0;



/**
 *	Atributo idVehiculo
 */
private int idVehiculo;



/**
 *	Atributo marca
 */
private string marca;



/**
 *	Atributo attribute
 */
private string attribute;



/**
 *	Atributo modelo
 */
private string modelo;



/**
 *	Atributo anyo
 */
private int anyo;



/**
 *	Atributo kilometros
 */
private int kilometros;



/**
 *	Atributo descripcion
 */
private string descripcion;



/**
 *	Atributo precioBase
 */
private double precioBase;



/**
 *	Atributo id
 */
private int id;






public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.CategoriaEN> Categoria {
        get { return categoria; } set { categoria = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> Anuncio {
        get { return anuncio; } set { anuncio = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> Anuncio_0 {
        get { return anuncio_0; } set { anuncio_0 = value;  }
}



public virtual int IdVehiculo {
        get { return idVehiculo; } set { idVehiculo = value;  }
}



public virtual string Marca {
        get { return marca; } set { marca = value;  }
}



public virtual string Attribute {
        get { return attribute; } set { attribute = value;  }
}



public virtual string Modelo {
        get { return modelo; } set { modelo = value;  }
}



public virtual int Anyo {
        get { return anyo; } set { anyo = value;  }
}



public virtual int Kilometros {
        get { return kilometros; } set { kilometros = value;  }
}



public virtual string Descripcion {
        get { return descripcion; } set { descripcion = value;  }
}



public virtual double PrecioBase {
        get { return precioBase; } set { precioBase = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}





public VehiculoEN()
{
        categoria = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.CategoriaEN>();
        anuncio = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN>();
        anuncio_0 = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN>();
}



public VehiculoEN(int id, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.CategoriaEN> categoria, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> anuncio, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> anuncio_0, int idVehiculo, string marca, string attribute, string modelo, int anyo, int kilometros, string descripcion, double precioBase
                  )
{
        this.init (Id, categoria, anuncio, anuncio_0, idVehiculo, marca, attribute, modelo, anyo, kilometros, descripcion, precioBase);
}


public VehiculoEN(VehiculoEN vehiculo)
{
        this.init (vehiculo.Id, vehiculo.Categoria, vehiculo.Anuncio, vehiculo.Anuncio_0, vehiculo.IdVehiculo, vehiculo.Marca, vehiculo.Attribute, vehiculo.Modelo, vehiculo.Anyo, vehiculo.Kilometros, vehiculo.Descripcion, vehiculo.PrecioBase);
}

private void init (int id
                   , System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.CategoriaEN> categoria, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> anuncio, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> anuncio_0, int idVehiculo, string marca, string attribute, string modelo, int anyo, int kilometros, string descripcion, double precioBase)
{
        this.Id = id;


        this.Categoria = categoria;

        this.Anuncio = anuncio;

        this.Anuncio_0 = anuncio_0;

        this.IdVehiculo = idVehiculo;

        this.Marca = marca;

        this.Attribute = attribute;

        this.Modelo = modelo;

        this.Anyo = anyo;

        this.Kilometros = kilometros;

        this.Descripcion = descripcion;

        this.PrecioBase = precioBase;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        VehiculoEN t = obj as VehiculoEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
