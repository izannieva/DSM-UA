
using System;
// Definición clase PagoEN
namespace SellYourTunningGen.ApplicationCore.EN.SellYourTunning
{
public partial class PagoEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo importe
 */
private double importe;



/**
 *	Atributo metodo
 */
private string metodo;



/**
 *	Atributo estado
 */
private SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoPagoEnum estado;



/**
 *	Atributo pagar
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pagar;



/**
 *	Atributo usuario
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN> usuario;



/**
 *	Atributo idAnuncio
 */
private int idAnuncio;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual double Importe {
        get { return importe; } set { importe = value;  }
}



public virtual string Metodo {
        get { return metodo; } set { metodo = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoPagoEnum Estado {
        get { return estado; } set { estado = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> Pagar {
        get { return pagar; } set { pagar = value;  }
}



public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN> Usuario {
        get { return usuario; } set { usuario = value;  }
}



public virtual int IdAnuncio {
        get { return idAnuncio; } set { idAnuncio = value;  }
}





public PagoEN()
{
        pagar = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN>();
        usuario = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN>();
}



public PagoEN(int id, double importe, string metodo, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoPagoEnum estado, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pagar, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN> usuario, int idAnuncio
              )
{
        this.init (Id, importe, metodo, estado, pagar, usuario, idAnuncio);
}


public PagoEN(PagoEN pago)
{
        this.init (pago.Id, pago.Importe, pago.Metodo, pago.Estado, pago.Pagar, pago.Usuario, pago.IdAnuncio);
}

private void init (int id
                   , double importe, string metodo, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoPagoEnum estado, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN> pagar, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN> usuario, int idAnuncio)
{
        this.Id = id;


        this.Importe = importe;

        this.Metodo = metodo;

        this.Estado = estado;

        this.Pagar = pagar;

        this.Usuario = usuario;

        this.IdAnuncio = idAnuncio;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        PagoEN t = obj as PagoEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
