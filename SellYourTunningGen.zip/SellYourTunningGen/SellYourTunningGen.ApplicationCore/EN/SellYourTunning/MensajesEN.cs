
using System;
// Definición clase MensajesEN
namespace SellYourTunningGen.ApplicationCore.EN.SellYourTunning
{
public partial class MensajesEN
{
/**
 *	Atributo emisor
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN emisor;



/**
 *	Atributo receptor
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN receptor;



/**
 *	Atributo contiene
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN contiene;



/**
 *	Atributo idMensaje
 */
private int idMensaje;



/**
 *	Atributo contenido
 */
private string contenido;



/**
 *	Atributo fechaEnvio
 */
private string fechaEnvio;



/**
 *	Atributo id
 */
private int id;






public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN Emisor {
        get { return emisor; } set { emisor = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN Receptor {
        get { return receptor; } set { receptor = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN Contiene {
        get { return contiene; } set { contiene = value;  }
}



public virtual int IdMensaje {
        get { return idMensaje; } set { idMensaje = value;  }
}



public virtual string Contenido {
        get { return contenido; } set { contenido = value;  }
}



public virtual string FechaEnvio {
        get { return fechaEnvio; } set { fechaEnvio = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}





public MensajesEN()
{
}



public MensajesEN(int id, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN emisor, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN receptor, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN contiene, int idMensaje, string contenido, string fechaEnvio
                  )
{
        this.init (Id, emisor, receptor, contiene, idMensaje, contenido, fechaEnvio);
}


public MensajesEN(MensajesEN mensajes)
{
        this.init (mensajes.Id, mensajes.Emisor, mensajes.Receptor, mensajes.Contiene, mensajes.IdMensaje, mensajes.Contenido, mensajes.FechaEnvio);
}

private void init (int id
                   , SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN emisor, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN receptor, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN contiene, int idMensaje, string contenido, string fechaEnvio)
{
        this.Id = id;


        this.Emisor = emisor;

        this.Receptor = receptor;

        this.Contiene = contiene;

        this.IdMensaje = idMensaje;

        this.Contenido = contenido;

        this.FechaEnvio = fechaEnvio;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        MensajesEN t = obj as MensajesEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
