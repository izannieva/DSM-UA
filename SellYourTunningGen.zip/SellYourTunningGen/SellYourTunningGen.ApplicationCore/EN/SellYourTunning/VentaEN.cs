
using System;
// Definición clase VentaEN
namespace SellYourTunningGen.ApplicationCore.EN.SellYourTunning
{
public partial class VentaEN
{
/**
 *	Atributo usuario
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN usuario;



/**
 *	Atributo anuncio
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN anuncio;



/**
 *	Atributo fechaVenta
 */
private Nullable<DateTime> fechaVenta;



/**
 *	Atributo cantidad
 */
private double cantidad;



/**
 *	Atributo tipoVenta
 */
private string tipoVenta;



/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo venta
 */
private SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN venta;



/**
 *	Atributo idAnuncio
 */
private int idAnuncio;






public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN Usuario {
        get { return usuario; } set { usuario = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN Anuncio {
        get { return anuncio; } set { anuncio = value;  }
}



public virtual Nullable<DateTime> FechaVenta {
        get { return fechaVenta; } set { fechaVenta = value;  }
}



public virtual double Cantidad {
        get { return cantidad; } set { cantidad = value;  }
}



public virtual string TipoVenta {
        get { return tipoVenta; } set { tipoVenta = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN Venta {
        get { return venta; } set { venta = value;  }
}



public virtual int IdAnuncio {
        get { return idAnuncio; } set { idAnuncio = value;  }
}





public VentaEN()
{
}



public VentaEN(int id, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN usuario, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN anuncio, Nullable<DateTime> fechaVenta, double cantidad, string tipoVenta, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN venta, int idAnuncio
               )
{
        this.init (Id, usuario, anuncio, fechaVenta, cantidad, tipoVenta, venta, idAnuncio);
}


public VentaEN(VentaEN venta)
{
        this.init (venta.Id, venta.Usuario, venta.Anuncio, venta.FechaVenta, venta.Cantidad, venta.TipoVenta, venta.Venta, venta.IdAnuncio);
}

private void init (int id
                   , SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN usuario, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN anuncio, Nullable<DateTime> fechaVenta, double cantidad, string tipoVenta, SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN venta, int idAnuncio)
{
        this.Id = id;


        this.Usuario = usuario;

        this.Anuncio = anuncio;

        this.FechaVenta = fechaVenta;

        this.Cantidad = cantidad;

        this.TipoVenta = tipoVenta;

        this.Venta = venta;

        this.IdAnuncio = idAnuncio;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        VentaEN t = obj as VentaEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
