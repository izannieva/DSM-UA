
using System;
// Definición clase CategoriaEN
namespace SellYourTunningGen.ApplicationCore.EN.SellYourTunning
{
public partial class CategoriaEN
{
/**
 *	Atributo contiene
 */
private System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> contiene;



/**
 *	Atributo idCategoria
 */
private int idCategoria;



/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo id
 */
private int id;






public virtual System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> Contiene {
        get { return contiene; } set { contiene = value;  }
}



public virtual int IdCategoria {
        get { return idCategoria; } set { idCategoria = value;  }
}



public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}





public CategoriaEN()
{
        contiene = new System.Collections.Generic.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN>();
}



public CategoriaEN(int id, System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> contiene, int idCategoria, string nombre
                   )
{
        this.init (Id, contiene, idCategoria, nombre);
}


public CategoriaEN(CategoriaEN categoria)
{
        this.init (categoria.Id, categoria.Contiene, categoria.IdCategoria, categoria.Nombre);
}

private void init (int id
                   , System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> contiene, int idCategoria, string nombre)
{
        this.Id = id;


        this.Contiene = contiene;

        this.IdCategoria = idCategoria;

        this.Nombre = nombre;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        CategoriaEN t = obj as CategoriaEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
