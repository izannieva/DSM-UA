
using System;
using System.Text;
using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.Utils;



namespace SellYourTunningGen.ApplicationCore.CP.SellYourTunning
{
public partial class PagoCP : GenericBasicCP
{
public PagoCP(GenericSessionCP currentSession)
        : base (currentSession)
{
}

public PagoCP(GenericSessionCP currentSession, GenericUnitOfWorkUtils unitUtils)
        : base (currentSession, unitUtils)
{
}
}
}
