
using System;
using System.Text;

using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;



/*PROTECTED REGION ID(usingSellYourTunningGen.ApplicationCore.CP.SellYourTunning_Anuncios_modify) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace SellYourTunningGen.ApplicationCore.CP.SellYourTunning
{
public partial class AnunciosCP : GenericBasicCP
{
public void Modify (int p_Anuncios_OID, int p_idVehiculo, string p_titulo, Nullable<DateTime> p_fechaPublicacion, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum p_estado, double p_precioVenta, bool p_destacado)
{
        /*PROTECTED REGION ID(SellYourTunningGen.ApplicationCore.CP.SellYourTunning_Anuncios_modify) ENABLED START*/

        AnunciosCEN anunciosCEN = null;



        try
        {
                CPSession.SessionInitializeTransaction ();
                anunciosCEN = new  AnunciosCEN (CPSession.UnitRepo.AnunciosRepository);




                AnunciosEN anunciosEN = null;
                //Initialized AnunciosEN
                anunciosEN = new AnunciosEN ();
                anunciosEN.Id = p_Anuncios_OID;
                anunciosEN.IdVehiculo = p_idVehiculo;
                anunciosEN.Titulo = p_titulo;
                anunciosEN.FechaPublicacion = p_fechaPublicacion;
                anunciosEN.Estado = p_estado;
                anunciosEN.PrecioVenta = p_precioVenta;
                anunciosEN.Destacado = p_destacado;


                CPSession.Commit ();
        }
        catch (Exception ex)
        {
                CPSession.RollBack ();
                throw ex;
        }
        finally
        {
                CPSession.SessionClose ();
        }


        /*PROTECTED REGION END*/
}
}
}
