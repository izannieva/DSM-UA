
using System;
using System.Text;

using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;



/*PROTECTED REGION ID(usingSellYourTunningGen.ApplicationCore.CP.SellYourTunning_Venta_new_) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace SellYourTunningGen.ApplicationCore.CP.SellYourTunning
{
public partial class VentaCP : GenericBasicCP
{
public SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VentaEN New_ (int p_usuario, Nullable<DateTime> p_fechaVenta, double p_cantidad, string p_tipoVenta, int p_venta, int p_idAnuncio)
{
        /*PROTECTED REGION ID(SellYourTunningGen.ApplicationCore.CP.SellYourTunning_Venta_new_) ENABLED START*/

        VentaCEN ventaCEN = null;
        VentaEN result = null;

        try
        {
                CPSession.SessionInitializeTransaction ();
                ventaCEN = new VentaCEN (CPSession.UnitRepo.VentaRepository);

                var anuncioRepo = CPSession.UnitRepo.AnunciosRepository;
                var pagoRepo = CPSession.UnitRepo.PagoRepository;

                Console.WriteLine ("Intentando vender anuncio con ID: " + p_idAnuncio);

                // 1️⃣ Validar y actualizar estado del anuncio
                var anuncio = anuncioRepo.ReadOIDDefault (p_idAnuncio);
                if (anuncio == null)
                        throw new Exception ("Anuncio no encontrado.");
                if (anuncio.Estado == Enumerated.SellYourTunning.EstadoEnum.vendido)
                        throw new Exception ("El anuncio ya ha sido vendido.");

                anuncio.Estado = Enumerated.SellYourTunning.EstadoEnum.vendido;
                anuncioRepo.Modify (anuncio);

                Console.WriteLine ("Anuncio " + p_idAnuncio + "marcado como vendido.");

                // 2️⃣ Crear pago
                PagoEN pagoEN = new PagoEN
                {
                        Importe = p_cantidad,
                        Metodo = p_tipoVenta,
                        Estado = Enumerated.SellYourTunning.EstadoPagoEnum.pendiente,
                        IdAnuncio = p_idAnuncio
                };

                int idPago = pagoRepo.New_ (pagoEN);
                pagoEN.Id = idPago;

                Console.WriteLine ("Pago creado con ID: " + idPago + ", Importe: " + p_cantidad + ", Método: " + p_tipoVenta);


                // 3️⃣ Crear venta vinculada al pago
                VentaEN ventaEN = new VentaEN
                {
                        Usuario = new UsuarioEN {
                                Id = p_usuario
                        },
                        FechaVenta = p_fechaVenta ?? DateTime.Now,
                        Cantidad = p_cantidad,
                        TipoVenta = p_tipoVenta,
                        Venta = pagoEN
                };

                int oid = ventaCEN.get_IVentaRepository ().New_ (ventaEN);
                result = ventaCEN.get_IVentaRepository ().ReadOIDDefault (oid);

                Console.WriteLine ("Venta creada con ID: " + oid + " para usuario " + p_usuario);

                CPSession.Commit ();
        }
        catch (Exception ex)
        {
                CPSession.RollBack ();
                throw new Exception ("Error al completar la venta: " + ex.Message, ex);
        }
        finally
        {
                CPSession.SessionClose ();
        }

        return result;

        /*PROTECTED REGION END*/
}
}
}
