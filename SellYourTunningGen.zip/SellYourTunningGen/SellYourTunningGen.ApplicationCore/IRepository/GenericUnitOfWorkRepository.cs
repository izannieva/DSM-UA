
using System;
using System.Collections.Generic;
using System.Text;

namespace SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning
{
public abstract class GenericUnitOfWorkRepository
{
protected IUsuarioRepository usuariorepository;
protected IMensajesRepository mensajesrepository;
protected IAnunciosRepository anunciosrepository;
protected IVehiculoRepository vehiculorepository;
protected IVentaRepository ventarepository;
protected ICategoriaRepository categoriarepository;
protected IPagoRepository pagorepository;


public abstract IUsuarioRepository UsuarioRepository {
        get;
}
public abstract IMensajesRepository MensajesRepository {
        get;
}
public abstract IAnunciosRepository AnunciosRepository {
        get;
}
public abstract IVehiculoRepository VehiculoRepository {
        get;
}
public abstract IVentaRepository VentaRepository {
        get;
}
public abstract ICategoriaRepository CategoriaRepository {
        get;
}
public abstract IPagoRepository PagoRepository {
        get;
}
}
}
