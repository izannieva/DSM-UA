
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;

namespace SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning
{
public partial interface IPagoRepository
{
void setSessionCP (GenericSessionCP session);

PagoEN ReadOIDDefault (int id
                       );

void ModifyDefault (PagoEN pago);

System.Collections.Generic.IList<PagoEN> ReadAllDefault (int first, int size);



System.Collections.Generic.IList<PagoEN> Consultar (int first, int size);


int New_ (PagoEN pago);

void Modify (PagoEN pago);


void Destroy (int id
              );


System.Collections.Generic.IList<PagoEN> ReadAll (int first, int size);
}
}
