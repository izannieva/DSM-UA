
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;

namespace SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning
{
public partial interface IVehiculoRepository
{
void setSessionCP (GenericSessionCP session);

VehiculoEN ReadOIDDefault (int id
                           );

void ModifyDefault (VehiculoEN vehiculo);

System.Collections.Generic.IList<VehiculoEN> ReadAllDefault (int first, int size);



System.Collections.Generic.IList<VehiculoEN> Consultar (int first, int size);


int New_ (VehiculoEN vehiculo);

void Modify (VehiculoEN vehiculo);


void Destroy (int id
              );


System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> FiltrarAnyo (int ? p_anyo);
}
}
