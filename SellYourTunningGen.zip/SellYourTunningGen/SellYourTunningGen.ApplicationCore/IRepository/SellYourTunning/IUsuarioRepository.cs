
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;

namespace SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning
{
public partial interface IUsuarioRepository
{
void setSessionCP (GenericSessionCP session);

UsuarioEN ReadOIDDefault (int id
                          );

void ModifyDefault (UsuarioEN usuario);

System.Collections.Generic.IList<UsuarioEN> ReadAllDefault (int first, int size);



System.Collections.Generic.IList<UsuarioEN> Consultar (int first, int size);


int New_ (UsuarioEN usuario);

void Modify (UsuarioEN usuario);


void Destroy (int id
              );
}
}
