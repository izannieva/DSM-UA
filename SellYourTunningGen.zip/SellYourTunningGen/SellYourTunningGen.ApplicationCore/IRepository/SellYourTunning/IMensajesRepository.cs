
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;

namespace SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning
{
public partial interface IMensajesRepository
{
void setSessionCP (GenericSessionCP session);

MensajesEN ReadOIDDefault (int id
                           );

void ModifyDefault (MensajesEN mensajes);

System.Collections.Generic.IList<MensajesEN> ReadAllDefault (int first, int size);



System.Collections.Generic.IList<MensajesEN> Consultar (int first, int size);


int New_ (MensajesEN mensajes);

void Modify (MensajesEN mensajes);


void Destroy (int id
              );
}
}
