
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;

namespace SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning
{
public partial interface IVentaRepository
{
void setSessionCP (GenericSessionCP session);

VentaEN ReadOIDDefault (int id
                        );

void ModifyDefault (VentaEN venta);

System.Collections.Generic.IList<VentaEN> ReadAllDefault (int first, int size);



System.Collections.Generic.IList<VentaEN> Consultar (int first, int size);


int New_ (VentaEN venta);

void Modify (VentaEN venta);


void Destroy (int id
              );
}
}
