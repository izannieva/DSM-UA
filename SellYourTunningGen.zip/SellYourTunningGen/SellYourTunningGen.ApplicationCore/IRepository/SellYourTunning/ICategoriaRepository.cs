
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;

namespace SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning
{
public partial interface ICategoriaRepository
{
void setSessionCP (GenericSessionCP session);

CategoriaEN ReadOIDDefault (int id
                            );

void ModifyDefault (CategoriaEN categoria);

System.Collections.Generic.IList<CategoriaEN> ReadAllDefault (int first, int size);



int New_ (CategoriaEN categoria);

void Modify (CategoriaEN categoria);


void Destroy (int id
              );


System.Collections.Generic.IList<CategoriaEN> Consultar (int first, int size);
}
}
