
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;

namespace SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning
{
public partial interface IAnunciosRepository
{
void setSessionCP (GenericSessionCP session);

AnunciosEN ReadOIDDefault (int id
                           );

void ModifyDefault (AnunciosEN anuncios);

System.Collections.Generic.IList<AnunciosEN> ReadAllDefault (int first, int size);




int New_ (AnunciosEN anuncios);

void Modify (AnunciosEN anuncios);


void Destroy (int id
              );





System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosDisponibles ();


System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosPorPrecio (double? p_min, double ? p_max);


System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosDestacados ();
}
}
