
using System;
using System.Text;
using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


/*PROTECTED REGION ID(usingSellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Anuncios_cambiarTitulo) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
public partial class AnunciosCEN
{
public void CambiarTitulo (int p_oid, string nuevoTitulo)
{
        /*PROTECTED REGION ID(SellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Anuncios_cambiarTitulo) ENABLED START*/

        AnunciosEN anuncioEN = _IAnunciosRepository.ReadOIDDefault (p_oid);

        if (anuncioEN != null) {
                anuncioEN.Titulo = nuevoTitulo;
                _IAnunciosRepository.Modify (anuncioEN);
        }

        /*PROTECTED REGION END*/
}
}
}
