
using System;
using System.Text;
using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


/*PROTECTED REGION ID(usingSellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Pago_readAll) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
public partial class PagoCEN
{
public System.Collections.Generic.IList<PagoEN> ReadAll (int first, int size)
{
        /*PROTECTED REGION ID(SellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Pago_readAll_customized) START*/

        System.Collections.Generic.IList<PagoEN> list = null;

        list = _IPagoRepository.ReadAll (first, size);
        return list;
        /*PROTECTED REGION END*/
}
}
}
