
using System;
using System.Text;
using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


/*PROTECTED REGION ID(usingSellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Anuncios_cambiarEstado) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
public partial class AnunciosCEN
{
public void CambiarEstado (int p_oid, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum nuevoEstado)
{
        /*PROTECTED REGION ID(SellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Anuncios_cambiarEstado) ENABLED START*/

        if (!Enum.IsDefined (typeof(Enumerated.SellYourTunning.EstadoEnum), nuevoEstado)) {
                throw new Exception ("El nuevo estado no es válido.");
        }

        // Obtener el anuncio a modificar
        AnunciosEN anuncio = _IAnunciosRepository.ReadOIDDefault (p_oid);

        if (anuncio == null) {
                throw new Exception ("No se ha encontrado el anuncio con el ID especificado.");
        }

        // Cambiar el estado del anuncio
        anuncio.Estado = nuevoEstado;

        // Actualizar el anuncio en el repositorio
        _IAnunciosRepository.Modify (anuncio);

        /*PROTECTED REGION END*/
}
}
}
