
using System;
using System.Text;
using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


/*PROTECTED REGION ID(usingSellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Pago_new_) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
public partial class PagoCEN
{
public int New_ (double p_importe, string p_metodo, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoPagoEnum p_estado, int p_idAnuncio)
{
        /*PROTECTED REGION ID(SellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Pago_new__customized) START*/

        PagoEN pagoEN = null;

        int oid;

        //Initialized PagoEN
        pagoEN = new PagoEN ();
        pagoEN.Importe = p_importe;

        pagoEN.Metodo = p_metodo;

        pagoEN.Estado = p_estado;

        pagoEN.IdAnuncio = p_idAnuncio;

        //Call to PagoRepository

        oid = _IPagoRepository.New_ (pagoEN);
        return oid;
        /*PROTECTED REGION END*/
}
}
}
