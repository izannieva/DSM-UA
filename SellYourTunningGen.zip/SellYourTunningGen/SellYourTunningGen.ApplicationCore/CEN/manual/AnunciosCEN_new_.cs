
using System;
using System.Text;
using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


/*PROTECTED REGION ID(usingSellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Anuncios_new_) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
public partial class AnunciosCEN
{
public int New_ (int p_publica, int p_idVehiculo, string p_titulo, Nullable<DateTime> p_fechaPublicacion, double p_precioVenta)
{
        /*PROTECTED REGION ID(SellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Anuncios_new__customized) START*/

        AnunciosEN anunciosEN = null;

        int oid;

        //Initialized AnunciosEN
        anunciosEN = new AnunciosEN ();

        if (p_publica != -1) {
                anunciosEN.Publica = new SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN ();
                anunciosEN.Publica.Id = p_publica;
        }

        anunciosEN.IdVehiculo = p_idVehiculo;

        anunciosEN.Titulo = p_titulo;

        anunciosEN.FechaPublicacion = p_fechaPublicacion;

        anunciosEN.PrecioVenta = p_precioVenta;

        //Call to AnunciosRepository

        oid = _IAnunciosRepository.New_ (anunciosEN);
        return oid;
        /*PROTECTED REGION END*/
}
}
}
