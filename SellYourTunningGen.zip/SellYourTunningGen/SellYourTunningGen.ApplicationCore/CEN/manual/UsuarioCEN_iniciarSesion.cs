
using System;
using System.Text;
using System.Collections.Generic;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


/*PROTECTED REGION ID(usingSellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Usuario_iniciarSesion) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
public partial class UsuarioCEN
{
public string IniciarSesion (int p_oid)
{
        /*PROTECTED REGION ID(SellYourTunningGen.ApplicationCore.CEN.SellYourTunning_Usuario_iniciarSesion) ENABLED START*/

        UsuarioEN usuario = _IUsuarioRepository.ReadOIDDefault (p_oid);

        if (usuario == null)
                throw new Exception ("Usuario no encontrado");

        // Aqu� podr�as generar un token de sesi�n real; por ahora devolvemos un mensaje simple
        string mensaje = "Usuario {usuario.Nombre} ha iniciado sesi�n correctamente.";

        return mensaje;

        /*PROTECTED REGION END*/
}
}
}
