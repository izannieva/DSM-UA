

using System;
using System.Text;
using System.Collections.Generic;

using SellYourTunningGen.ApplicationCore.Exceptions;

using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
/*
 *      Definition of the class VehiculoCEN
 *
 */
public partial class VehiculoCEN
{
private IVehiculoRepository _IVehiculoRepository;

public VehiculoCEN(IVehiculoRepository _IVehiculoRepository)
{
        this._IVehiculoRepository = _IVehiculoRepository;
}

public IVehiculoRepository get_IVehiculoRepository ()
{
        return this._IVehiculoRepository;
}

public System.Collections.Generic.IList<VehiculoEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<VehiculoEN> list = null;

        list = _IVehiculoRepository.Consultar (first, size);
        return list;
}
public int New_ (int p_idVehiculo, string p_marca, string p_attribute, string p_modelo, int p_anyo, int p_kilometros, string p_descripcion, double p_precioBase)
{
        VehiculoEN vehiculoEN = null;
        int oid;

        //Initialized VehiculoEN
        vehiculoEN = new VehiculoEN ();
        vehiculoEN.IdVehiculo = p_idVehiculo;

        vehiculoEN.Marca = p_marca;

        vehiculoEN.Attribute = p_attribute;

        vehiculoEN.Modelo = p_modelo;

        vehiculoEN.Anyo = p_anyo;

        vehiculoEN.Kilometros = p_kilometros;

        vehiculoEN.Descripcion = p_descripcion;

        vehiculoEN.PrecioBase = p_precioBase;



        oid = _IVehiculoRepository.New_ (vehiculoEN);
        return oid;
}

public void Modify (int p_Vehiculo_OID, int p_idVehiculo, string p_marca, string p_attribute, string p_modelo, int p_anyo, int p_kilometros, string p_descripcion, double p_precioBase)
{
        VehiculoEN vehiculoEN = null;

        //Initialized VehiculoEN
        vehiculoEN = new VehiculoEN ();
        vehiculoEN.Id = p_Vehiculo_OID;
        vehiculoEN.IdVehiculo = p_idVehiculo;
        vehiculoEN.Marca = p_marca;
        vehiculoEN.Attribute = p_attribute;
        vehiculoEN.Modelo = p_modelo;
        vehiculoEN.Anyo = p_anyo;
        vehiculoEN.Kilometros = p_kilometros;
        vehiculoEN.Descripcion = p_descripcion;
        vehiculoEN.PrecioBase = p_precioBase;
        //Call to VehiculoRepository

        _IVehiculoRepository.Modify (vehiculoEN);
}

public void Destroy (int id
                     )
{
        _IVehiculoRepository.Destroy (id);
}

public System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> FiltrarAnyo (int ? p_anyo)
{
        return _IVehiculoRepository.FiltrarAnyo (p_anyo);
}
}
}
