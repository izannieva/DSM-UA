

using System;
using System.Text;
using System.Collections.Generic;

using SellYourTunningGen.ApplicationCore.Exceptions;

using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
/*
 *      Definition of the class PagoCEN
 *
 */
public partial class PagoCEN
{
private IPagoRepository _IPagoRepository;

public PagoCEN(IPagoRepository _IPagoRepository)
{
        this._IPagoRepository = _IPagoRepository;
}

public IPagoRepository get_IPagoRepository ()
{
        return this._IPagoRepository;
}

public System.Collections.Generic.IList<PagoEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<PagoEN> list = null;

        list = _IPagoRepository.Consultar (first, size);
        return list;
}
public void Modify (int p_Pago_OID, double p_importe, string p_metodo, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoPagoEnum p_estado, int p_idAnuncio)
{
        PagoEN pagoEN = null;

        //Initialized PagoEN
        pagoEN = new PagoEN ();
        pagoEN.Id = p_Pago_OID;
        pagoEN.Importe = p_importe;
        pagoEN.Metodo = p_metodo;
        pagoEN.Estado = p_estado;
        pagoEN.IdAnuncio = p_idAnuncio;
        //Call to PagoRepository

        _IPagoRepository.Modify (pagoEN);
}

public void Destroy (int id
                     )
{
        _IPagoRepository.Destroy (id);
}
}
}
