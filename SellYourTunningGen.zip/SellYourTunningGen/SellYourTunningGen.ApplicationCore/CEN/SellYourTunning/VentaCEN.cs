

using System;
using System.Text;
using System.Collections.Generic;

using SellYourTunningGen.ApplicationCore.Exceptions;

using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
/*
 *      Definition of the class VentaCEN
 *
 */
public partial class VentaCEN
{
private IVentaRepository _IVentaRepository;

public VentaCEN(IVentaRepository _IVentaRepository)
{
        this._IVentaRepository = _IVentaRepository;
}

public IVentaRepository get_IVentaRepository ()
{
        return this._IVentaRepository;
}

public System.Collections.Generic.IList<VentaEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<VentaEN> list = null;

        list = _IVentaRepository.Consultar (first, size);
        return list;
}
public void Modify (int p_Venta_OID, Nullable<DateTime> p_fechaVenta, double p_cantidad, string p_tipoVenta, int p_idAnuncio)
{
        VentaEN ventaEN = null;

        //Initialized VentaEN
        ventaEN = new VentaEN ();
        ventaEN.Id = p_Venta_OID;
        ventaEN.FechaVenta = p_fechaVenta;
        ventaEN.Cantidad = p_cantidad;
        ventaEN.TipoVenta = p_tipoVenta;
        ventaEN.IdAnuncio = p_idAnuncio;
        //Call to VentaRepository

        _IVentaRepository.Modify (ventaEN);
}

public void Destroy (int id
                     )
{
        _IVentaRepository.Destroy (id);
}
}
}
