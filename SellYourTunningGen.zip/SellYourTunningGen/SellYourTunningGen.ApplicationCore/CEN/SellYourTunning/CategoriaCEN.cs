

using System;
using System.Text;
using System.Collections.Generic;

using SellYourTunningGen.ApplicationCore.Exceptions;

using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
/*
 *      Definition of the class CategoriaCEN
 *
 */
public partial class CategoriaCEN
{
private ICategoriaRepository _ICategoriaRepository;

public CategoriaCEN(ICategoriaRepository _ICategoriaRepository)
{
        this._ICategoriaRepository = _ICategoriaRepository;
}

public ICategoriaRepository get_ICategoriaRepository ()
{
        return this._ICategoriaRepository;
}

public int New_ (int p_idCategoria, string p_nombre)
{
        CategoriaEN categoriaEN = null;
        int oid;

        //Initialized CategoriaEN
        categoriaEN = new CategoriaEN ();
        categoriaEN.IdCategoria = p_idCategoria;

        categoriaEN.Nombre = p_nombre;



        oid = _ICategoriaRepository.New_ (categoriaEN);
        return oid;
}

public void Modify (int p_Categoria_OID, int p_idCategoria, string p_nombre)
{
        CategoriaEN categoriaEN = null;

        //Initialized CategoriaEN
        categoriaEN = new CategoriaEN ();
        categoriaEN.Id = p_Categoria_OID;
        categoriaEN.IdCategoria = p_idCategoria;
        categoriaEN.Nombre = p_nombre;
        //Call to CategoriaRepository

        _ICategoriaRepository.Modify (categoriaEN);
}

public void Destroy (int id
                     )
{
        _ICategoriaRepository.Destroy (id);
}

public System.Collections.Generic.IList<CategoriaEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<CategoriaEN> list = null;

        list = _ICategoriaRepository.Consultar (first, size);
        return list;
}
}
}
