

using System;
using System.Text;
using System.Collections.Generic;

using SellYourTunningGen.ApplicationCore.Exceptions;

using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
/*
 *      Definition of the class AnunciosCEN
 *
 */
public partial class AnunciosCEN
{
private IAnunciosRepository _IAnunciosRepository;

public AnunciosCEN(IAnunciosRepository _IAnunciosRepository)
{
        this._IAnunciosRepository = _IAnunciosRepository;
}

public IAnunciosRepository get_IAnunciosRepository ()
{
        return this._IAnunciosRepository;
}

public void Destroy (int id
                     )
{
        _IAnunciosRepository.Destroy (id);
}

public System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosDisponibles ()
{
        return _IAnunciosRepository.ConsultarAnunciosDisponibles ();
}
public System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosPorPrecio (double? p_min, double ? p_max)
{
        return _IAnunciosRepository.ConsultarAnunciosPorPrecio (p_min, p_max);
}
public System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosDestacados ()
{
        return _IAnunciosRepository.ConsultarAnunciosDestacados ();
}
}
}
