

using System;
using System.Text;
using System.Collections.Generic;

using SellYourTunningGen.ApplicationCore.Exceptions;

using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;


namespace SellYourTunningGen.ApplicationCore.CEN.SellYourTunning
{
/*
 *      Definition of the class MensajesCEN
 *
 */
public partial class MensajesCEN
{
private IMensajesRepository _IMensajesRepository;

public MensajesCEN(IMensajesRepository _IMensajesRepository)
{
        this._IMensajesRepository = _IMensajesRepository;
}

public IMensajesRepository get_IMensajesRepository ()
{
        return this._IMensajesRepository;
}

public System.Collections.Generic.IList<MensajesEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<MensajesEN> list = null;

        list = _IMensajesRepository.Consultar (first, size);
        return list;
}
public int New_ (int p_contiene, int p_idMensaje, string p_contenido, string p_fechaEnvio)
{
        MensajesEN mensajesEN = null;
        int oid;

        //Initialized MensajesEN
        mensajesEN = new MensajesEN ();

        if (p_contiene != -1) {
                // El argumento p_contiene -> Property contiene es oid = false
                // Lista de oids id
                mensajesEN.Contiene = new SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN ();
                mensajesEN.Contiene.Id = p_contiene;
        }

        mensajesEN.IdMensaje = p_idMensaje;

        mensajesEN.Contenido = p_contenido;

        mensajesEN.FechaEnvio = p_fechaEnvio;



        oid = _IMensajesRepository.New_ (mensajesEN);
        return oid;
}

public void Modify (int p_Mensajes_OID, int p_idMensaje, string p_contenido, string p_fechaEnvio)
{
        MensajesEN mensajesEN = null;

        //Initialized MensajesEN
        mensajesEN = new MensajesEN ();
        mensajesEN.Id = p_Mensajes_OID;
        mensajesEN.IdMensaje = p_idMensaje;
        mensajesEN.Contenido = p_contenido;
        mensajesEN.FechaEnvio = p_fechaEnvio;
        //Call to MensajesRepository

        _IMensajesRepository.Modify (mensajesEN);
}

public void Destroy (int id
                     )
{
        _IMensajesRepository.Destroy (id);
}
}
}
