
/*PROTECTED REGION ID(CreateDB_imports) ENABLED START*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using SellYourTunningGen.Infraestructure.Repository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.Infraestructure.CP;
/*PROTECTED REGION END*/
namespace InitializeDB
{
public class CreateDB
{
public static void Create (string databaseArg, string userArg, string passArg)
{
        String database = databaseArg;
        String user = userArg;
        String pass = passArg;

        // Conex DB
        SqlConnection cnn = new SqlConnection (@"Server=(local); database=master; integrated security=yes");

        // Order T-SQL create user
        String createUser = @"IF NOT EXISTS(SELECT name FROM master.dbo.syslogins WHERE name = '" + user + @"')
            BEGIN
                CREATE LOGIN ["                                                                                                                                     + user + @"] WITH PASSWORD=N'" + pass + @"', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
            END"                                                                                                                                                                                                                                                                                    ;

        //Order delete user if exist
        String deleteDataBase = @"if exists(select * from sys.databases where name = '" + database + "') DROP DATABASE [" + database + "]";
        //Order create databas
        string createBD = "CREATE DATABASE " + database;
        //Order associate user with database
        String associatedUser = @"USE [" + database + "];CREATE USER [" + user + "] FOR LOGIN [" + user + "];USE [" + database + "];EXEC sp_addrolemember N'db_owner', N'" + user + "'";
        SqlCommand cmd = null;

        try
        {
                // Open conex
                cnn.Open ();

                //Create user in SQLSERVER
                cmd = new SqlCommand (createUser, cnn);
                cmd.ExecuteNonQuery ();

                //DELETE database if exist
                cmd = new SqlCommand (deleteDataBase, cnn);
                cmd.ExecuteNonQuery ();

                //CREATE DB
                cmd = new SqlCommand (createBD, cnn);
                cmd.ExecuteNonQuery ();

                //Associate user with db
                cmd = new SqlCommand (associatedUser, cnn);
                cmd.ExecuteNonQuery ();

                System.Console.WriteLine ("DataBase create sucessfully..");
        }
        catch (Exception)
        {
                throw;
        }
        finally
        {
                if (cnn.State == ConnectionState.Open) {
                        cnn.Close ();
                }
        }
}

public static void InitializeData ()
{
        try
        {
                // Initialising  CENs
                UsuarioRepository usuariorepository = new UsuarioRepository ();
                UsuarioCEN usuariocen = new UsuarioCEN (usuariorepository);
                MensajesRepository mensajesrepository = new MensajesRepository ();
                MensajesCEN mensajescen = new MensajesCEN (mensajesrepository);
                AnunciosRepository anunciosrepository = new AnunciosRepository ();
                AnunciosCEN anuncioscen = new AnunciosCEN (anunciosrepository);
                VehiculoRepository vehiculorepository = new VehiculoRepository ();
                VehiculoCEN vehiculocen = new VehiculoCEN (vehiculorepository);
                VentaRepository ventarepository = new VentaRepository ();
                VentaCEN ventacen = new VentaCEN (ventarepository);
                CategoriaRepository categoriarepository = new CategoriaRepository ();
                CategoriaCEN categoriacen = new CategoriaCEN (categoriarepository);
                PagoRepository pagorepository = new PagoRepository ();
                PagoCEN pagocen = new PagoCEN (pagorepository);



                /*PROTECTED REGION ID(initializeDataMethod) ENABLED START*/
                try
                {
                        UsuarioRepository usuarioRepository = new UsuarioRepository ();
                        UsuarioCEN usuarioCEN = new UsuarioCEN (usuarioRepository);

                        VehiculoRepository vehiculoRepository = new VehiculoRepository ();
                        VehiculoCEN vehiculoCEN = new VehiculoCEN (vehiculoRepository);

                        AnunciosRepository anunciosRepository = new AnunciosRepository ();
                        AnunciosCEN anunciosCEN = new AnunciosCEN (anunciosRepository);

                        VentaRepository ventaRepository = new VentaRepository ();
                        VentaCEN ventaCEN = new VentaCEN (ventaRepository);

                        // -------------------
                        // Crear Usuarios
                        // -------------------
                        Console.WriteLine ("Creando usuarios...");
                        int idUsuario1 = usuarioCEN.New_ (1, "Juan Perez", "juan@mail.com", "123456");
                        UsuarioEN usuario1 = usuarioCEN.get_IUsuarioRepository ().ReadOIDDefault (idUsuario1);
                        usuario1.Telefono = "111-111-1111";
                        usuarioCEN.get_IUsuarioRepository ().Modify (usuario1);
                        Console.WriteLine ("Usuario 1 creado con Id: " + idUsuario1);

                        int idUsuario2 = usuarioCEN.New_ (2, "Ana Gomez", "ana@mail.com", "abcdef");
                        UsuarioEN usuario2 = usuarioCEN.get_IUsuarioRepository ().ReadOIDDefault (idUsuario2);
                        usuario2.Telefono = "222-222-2222";
                        usuarioCEN.get_IUsuarioRepository ().Modify (usuario2);
                        Console.WriteLine ("Usuario 2 creado con Id: " + idUsuario2);

                        // -------------------
                        // Crear Vehículos
                        // -------------------
                        Console.WriteLine ("Creando vehículos...");
                        int idVehiculo1 = vehiculoCEN.New_ (1, "Toyota", "Sedan", "Corolla", 2020, 15000, "Muy cuidado", 15000);
                        int idVehiculo2 = vehiculoCEN.New_ (2, "Ford", "Hatchback", "Fiesta", 2018, 30000, "Segundo dueño", 10000);
                        Console.WriteLine ("Vehículos creados: " + idVehiculo1 + " (Corolla), " + idVehiculo2 + " (Fiesta)");

                        // -------------------
                        // Crear Anuncios
                        // -------------------
                        Console.WriteLine ("Creando anuncios...");
                        int idAnuncio1 = anunciosCEN.New_ (idUsuario1, idVehiculo1, "Venta Corolla 2020", DateTime.Now, 15000);
                        int idAnuncio2 = anunciosCEN.New_ (idUsuario2, idVehiculo2, "Venta Fiesta 2018", DateTime.Now, 10000);
                        Console.WriteLine ("Anuncio 1 creado con Id REAL: " + idAnuncio1);
                        Console.WriteLine ("Anuncio 2 creado con Id REAL: " + idAnuncio2);

                        // -------------------
                        // Cancelar Anuncio Fiesta
                        // -------------------
                        Console.WriteLine ("Cancelando anuncio de Fiesta...");
                        AnunciosCP anunciosCP = new AnunciosCP (new SessionCPNHibernate ());
                        anunciosCP.Modify (idAnuncio2, idVehiculo2, "Venta Fiesta 2018", DateTime.Now,
                                SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum.cancelado,
                                10000, false);
                        Console.WriteLine ("Anuncio Fiesta cancelado correctamente.");

                        // -------------------
                        // Completar Venta del Corolla
                        // -------------------
                        Console.WriteLine ("Realizando venta del Corolla...");
                        VentaCP ventaCP = new VentaCP (new SessionCPNHibernate ());
                        VentaEN venta = ventaCP.New_ (idUsuario2, DateTime.Now, 15000, "efectivo", 0, idAnuncio1);

                        Console.WriteLine ("Datos de venta generados:");
                        Console.WriteLine ("Usuario: " + venta.Usuario.Id);
                        Console.WriteLine ("Cantidad: " + venta.Cantidad);
                        Console.WriteLine ("Tipo Venta: " + venta.TipoVenta);
                        Console.WriteLine ("Anuncio vendido Id: " + idAnuncio1);

                        // ================================
                        // DATOS DE PRUEBA PARA LOS FILTROS
                        // ================================
                        Console.WriteLine ("=== Creando anuncios de prueba ===");

                        // Crear anuncios de prueba usando el ID real del usuario
                        int a1 = anunciosCEN.New_ (idUsuario1, 0, "BMW Serie 3 2015", DateTime.Now, 7000);
                        int a2 = anunciosCEN.New_ (idUsuario1, 0, "Toyota Corolla 2018", DateTime.Now, 4000);
                        int a3 = anunciosCEN.New_ (idUsuario1, 0, "Mercedes C220 2012", DateTime.Now, 5000);

                        // Cambiar estado de los anuncios a disponible
                        anunciosCEN.CambiarEstado (a1, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum.disponible);
                        anunciosCEN.CambiarEstado (a2, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum.disponible);
                        anunciosCEN.CambiarEstado (a3, SellYourTunningGen.ApplicationCore.Enumerated.SellYourTunning.EstadoEnum.disponible);

                        Console.WriteLine ("Anuncios creados: " + a1 + ", " + a2 + ", " + a3);

                        // --------------------
                        // FILTRO 1: Disponibles
                        // --------------------
                        Console.WriteLine ("\n[TEST] ConsultarAnunciosDisponibles()");
                        IList<AnunciosEN> listaDisp = anunciosCEN.ConsultarAnunciosDisponibles ();
                        foreach (AnunciosEN an in listaDisp) {
                                Console.WriteLine (" - " + an.Id + ": " + an.Titulo + " (" + an.PrecioVenta + "€) Estado=" + an.Estado);
                        }

                        // --------------------
                        // FILTRO 2: Por rango de precio
                        // --------------------
                        Console.WriteLine ("\n[TEST] ConsultarAnunciosPorPrecio(3500, 8000)");
                        IList<AnunciosEN> rango = anunciosCEN.ConsultarAnunciosPorPrecio (3500, 8000);
                        foreach (AnunciosEN an in rango) {
                                Console.WriteLine (" - " + an.Id + ": " + an.Titulo + " (" + an.PrecioVenta + "€)");
                        }

                        // --------------------
                        // FILTRO 3: Destacados
                        // --------------------
                        anunciosCEN.DestacarAnuncio (a1);
                        anunciosCEN.DestacarAnuncio (a3);

                        Console.WriteLine ("\n[TEST] ConsultarAnunciosDestacados()");
                        IList<AnunciosEN> dest = anunciosCEN.ConsultarAnunciosDestacados ();
                        foreach (AnunciosEN an in dest) {
                                Console.WriteLine (" - " + an.Id + ": " + an.Titulo + " DESTACADO");
                        }

                        // --------------------
                        // FILTRO AÑO VEHÍCULO
                        // --------------------
                        Console.WriteLine ("\n=== Datos de prueba Vehiculo para filtro por año ===");
                        int v1 = vehiculoCEN.New_ (0, "BMW", "berlina", "Serie 3", 2015, 150000, "BMW Serie 3 2015", 9000);
                        int v2 = vehiculoCEN.New_ (0, "Ford", "hatchback", "Fiesta", 2018, 80000, "Ford Fiesta 2018", 6000);
                        int v3 = vehiculoCEN.New_ (0, "Toyota", "sedan", "Corolla", 2015, 40000, "Corolla 2015", 11000);

                        Console.WriteLine ("Vehículos creados: " + v1 + ", " + v2 + ", " + v3);

                        Console.WriteLine ("\n[TEST] consultarVehiculosPorAnyo(2015)");
                        IList<VehiculoEN> veh2015 = vehiculoCEN.FiltrarAnyo (2015);
                        foreach (VehiculoEN v in veh2015) {
                                Console.WriteLine (" - " + v.Id + ": " + v.Marca + " " + v.Modelo + " (" + v.Anyo + ")");
                        }
                }
                catch (Exception ex)
                {
                        Console.WriteLine ("Error inicializando datos: " + ex.Message);
                        if (ex.InnerException != null)
                                Console.WriteLine ("Detalle interno: " + ex.InnerException.Message);
                }

                /*PROTECTED REGION END*/
        }
        catch (Exception ex)
        {
                System.Console.WriteLine (ex.InnerException);
                throw;
        }
}
}
}
