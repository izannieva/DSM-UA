
using System;
using System.Text;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;
using SellYourTunningGen.Infraestructure.EN.SellYourTunning;


/*
 * Clase Anuncios:
 *
 */

namespace SellYourTunningGen.Infraestructure.Repository.SellYourTunning
{
public partial class AnunciosRepository : BasicRepository, IAnunciosRepository
{
public AnunciosRepository() : base ()
{
}


public AnunciosRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public AnunciosEN ReadOIDDefault (int id
                                  )
{
        AnunciosEN anunciosEN = null;

        try
        {
                SessionInitializeTransaction ();
                anunciosEN = (AnunciosEN)session.Get (typeof(AnunciosNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return anunciosEN;
}

public System.Collections.Generic.IList<AnunciosEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<AnunciosEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(AnunciosNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<AnunciosEN>();
                        else
                                result = session.CreateCriteria (typeof(AnunciosNH)).List<AnunciosEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in AnunciosRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (AnunciosEN anuncios)
{
        try
        {
                SessionInitializeTransaction ();
                AnunciosNH anunciosNH = (AnunciosNH)session.Load (typeof(AnunciosNH), anuncios.Id);






                anunciosNH.IdVehiculo = anuncios.IdVehiculo;


                anunciosNH.Titulo = anuncios.Titulo;


                anunciosNH.FechaPublicacion = anuncios.FechaPublicacion;


                anunciosNH.Estado = anuncios.Estado;


                anunciosNH.PrecioVenta = anuncios.PrecioVenta;


                anunciosNH.Destacado = anuncios.Destacado;

                session.Update (anunciosNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in AnunciosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int New_ (AnunciosEN anuncios)
{
        AnunciosNH anunciosNH = new AnunciosNH (anuncios);

        try
        {
                SessionInitializeTransaction ();
                if (anuncios.Publica != null) {
                        // Argumento OID y no colección.
                        anunciosNH
                        .Publica = (SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN)session.Load (typeof(SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN), anuncios.Publica.Id);

                        anunciosNH.Publica.Pertenece
                        .Add (anunciosNH);
                }

                session.Save (anunciosNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in AnunciosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return anunciosNH.Id;
}

public void Modify (AnunciosEN anuncios)
{
        try
        {
                SessionInitializeTransaction ();
                AnunciosNH anunciosNH = (AnunciosNH)session.Load (typeof(AnunciosNH), anuncios.Id);

                anunciosNH.IdVehiculo = anuncios.IdVehiculo;


                anunciosNH.Titulo = anuncios.Titulo;


                anunciosNH.FechaPublicacion = anuncios.FechaPublicacion;


                anunciosNH.Estado = anuncios.Estado;


                anunciosNH.PrecioVenta = anuncios.PrecioVenta;


                anunciosNH.Destacado = anuncios.Destacado;

                session.Update (anunciosNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in AnunciosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                AnunciosNH anunciosNH = (AnunciosNH)session.Load (typeof(AnunciosNH), id);
                session.Delete (anunciosNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in AnunciosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

public System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosDisponibles ()
{
        System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM AnunciosNH self where FROM AnunciosNH a WHERE a.Estado = 1";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("AnunciosNHconsultarAnunciosDisponiblesHQL");

                result = query.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in AnunciosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
public System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosPorPrecio (double? p_min, double ? p_max)
{
        System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM AnunciosNH self where FROM AnunciosNH a WHERE a.PrecioVenta >= :p_min AND a.PrecioVenta <= :p_max";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("AnunciosNHconsultarAnunciosPorPrecioHQL");
                query.SetParameter ("p_min", p_min);
                query.SetParameter ("p_max", p_max);

                result = query.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in AnunciosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
public System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> ConsultarAnunciosDestacados ()
{
        System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM AnunciosNH self where FROM AnunciosNH a WHERE a.Destacado = true";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("AnunciosNHconsultarAnunciosDestacadosHQL");

                result = query.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in AnunciosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
