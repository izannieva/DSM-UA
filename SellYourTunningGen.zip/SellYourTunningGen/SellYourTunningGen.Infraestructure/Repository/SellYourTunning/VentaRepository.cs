
using System;
using System.Text;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;
using SellYourTunningGen.Infraestructure.EN.SellYourTunning;


/*
 * Clase Venta:
 *
 */

namespace SellYourTunningGen.Infraestructure.Repository.SellYourTunning
{
public partial class VentaRepository : BasicRepository, IVentaRepository
{
public VentaRepository() : base ()
{
}


public VentaRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public VentaEN ReadOIDDefault (int id
                               )
{
        VentaEN ventaEN = null;

        try
        {
                SessionInitializeTransaction ();
                ventaEN = (VentaEN)session.Get (typeof(VentaNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return ventaEN;
}

public System.Collections.Generic.IList<VentaEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<VentaEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(VentaNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<VentaEN>();
                        else
                                result = session.CreateCriteria (typeof(VentaNH)).List<VentaEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VentaRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (VentaEN venta)
{
        try
        {
                SessionInitializeTransaction ();
                VentaNH ventaNH = (VentaNH)session.Load (typeof(VentaNH), venta.Id);



                ventaNH.FechaVenta = venta.FechaVenta;


                ventaNH.Cantidad = venta.Cantidad;


                ventaNH.TipoVenta = venta.TipoVenta;



                ventaNH.IdAnuncio = venta.IdAnuncio;

                session.Update (ventaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VentaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public System.Collections.Generic.IList<VentaEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<VentaEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(VentaNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<VentaEN>();
                else
                        result = session.CreateCriteria (typeof(VentaNH)).List<VentaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VentaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}

public int New_ (VentaEN venta)
{
        VentaNH ventaNH = new VentaNH (venta);

        try
        {
                SessionInitializeTransaction ();
                if (venta.Usuario != null) {
                        // Argumento OID y no colección.
                        ventaNH
                        .Usuario = (SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN)session.Load (typeof(SellYourTunningGen.ApplicationCore.EN.SellYourTunning.UsuarioEN), venta.Usuario.Id);

                        ventaNH.Usuario.Pago
                        .Add (ventaNH);
                }
                if (venta.Venta != null) {
                        // Argumento OID y no colección.
                        ventaNH
                        .Venta = (SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN)session.Load (typeof(SellYourTunningGen.ApplicationCore.EN.SellYourTunning.PagoEN), venta.Venta.Id);

                        ventaNH.Venta.Pagar
                        .Add (ventaNH);
                }

                session.Save (ventaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VentaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return ventaNH.Id;
}

public void Modify (VentaEN venta)
{
        try
        {
                SessionInitializeTransaction ();
                VentaNH ventaNH = (VentaNH)session.Load (typeof(VentaNH), venta.Id);

                ventaNH.FechaVenta = venta.FechaVenta;


                ventaNH.Cantidad = venta.Cantidad;


                ventaNH.TipoVenta = venta.TipoVenta;


                ventaNH.IdAnuncio = venta.IdAnuncio;

                session.Update (ventaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VentaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                VentaNH ventaNH = (VentaNH)session.Load (typeof(VentaNH), id);
                session.Delete (ventaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VentaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
}
}
