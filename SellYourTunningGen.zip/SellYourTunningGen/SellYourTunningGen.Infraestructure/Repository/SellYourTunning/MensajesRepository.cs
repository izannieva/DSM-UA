
using System;
using System.Text;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;
using SellYourTunningGen.Infraestructure.EN.SellYourTunning;


/*
 * Clase Mensajes:
 *
 */

namespace SellYourTunningGen.Infraestructure.Repository.SellYourTunning
{
public partial class MensajesRepository : BasicRepository, IMensajesRepository
{
public MensajesRepository() : base ()
{
}


public MensajesRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public MensajesEN ReadOIDDefault (int id
                                  )
{
        MensajesEN mensajesEN = null;

        try
        {
                SessionInitializeTransaction ();
                mensajesEN = (MensajesEN)session.Get (typeof(MensajesNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return mensajesEN;
}

public System.Collections.Generic.IList<MensajesEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<MensajesEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(MensajesNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<MensajesEN>();
                        else
                                result = session.CreateCriteria (typeof(MensajesNH)).List<MensajesEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in MensajesRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (MensajesEN mensajes)
{
        try
        {
                SessionInitializeTransaction ();
                MensajesNH mensajesNH = (MensajesNH)session.Load (typeof(MensajesNH), mensajes.Id);




                mensajesNH.IdMensaje = mensajes.IdMensaje;


                mensajesNH.Contenido = mensajes.Contenido;


                mensajesNH.FechaEnvio = mensajes.FechaEnvio;

                session.Update (mensajesNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in MensajesRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public System.Collections.Generic.IList<MensajesEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<MensajesEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(MensajesNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<MensajesEN>();
                else
                        result = session.CreateCriteria (typeof(MensajesNH)).List<MensajesEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in MensajesRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}

public int New_ (MensajesEN mensajes)
{
        MensajesNH mensajesNH = new MensajesNH (mensajes);

        try
        {
                SessionInitializeTransaction ();
                if (mensajes.Contiene != null) {
                        // Argumento OID y no colección.
                        mensajesNH
                        .Contiene = (SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN)session.Load (typeof(SellYourTunningGen.ApplicationCore.EN.SellYourTunning.AnunciosEN), mensajes.Contiene.Id);

                        mensajesNH.Contiene.Pertenece
                        .Add (mensajesNH);
                }

                session.Save (mensajesNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in MensajesRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return mensajesNH.Id;
}

public void Modify (MensajesEN mensajes)
{
        try
        {
                SessionInitializeTransaction ();
                MensajesNH mensajesNH = (MensajesNH)session.Load (typeof(MensajesNH), mensajes.Id);

                mensajesNH.IdMensaje = mensajes.IdMensaje;


                mensajesNH.Contenido = mensajes.Contenido;


                mensajesNH.FechaEnvio = mensajes.FechaEnvio;

                session.Update (mensajesNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in MensajesRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                MensajesNH mensajesNH = (MensajesNH)session.Load (typeof(MensajesNH), id);
                session.Delete (mensajesNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in MensajesRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
}
}
