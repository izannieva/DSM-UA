
using System;
using System.Text;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;
using SellYourTunningGen.Infraestructure.EN.SellYourTunning;


/*
 * Clase Categoria:
 *
 */

namespace SellYourTunningGen.Infraestructure.Repository.SellYourTunning
{
public partial class CategoriaRepository : BasicRepository, ICategoriaRepository
{
public CategoriaRepository() : base ()
{
}


public CategoriaRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public CategoriaEN ReadOIDDefault (int id
                                   )
{
        CategoriaEN categoriaEN = null;

        try
        {
                SessionInitializeTransaction ();
                categoriaEN = (CategoriaEN)session.Get (typeof(CategoriaNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return categoriaEN;
}

public System.Collections.Generic.IList<CategoriaEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<CategoriaEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(CategoriaNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<CategoriaEN>();
                        else
                                result = session.CreateCriteria (typeof(CategoriaNH)).List<CategoriaEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriaRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (CategoriaEN categoria)
{
        try
        {
                SessionInitializeTransaction ();
                CategoriaNH categoriaNH = (CategoriaNH)session.Load (typeof(CategoriaNH), categoria.Id);


                categoriaNH.IdCategoria = categoria.IdCategoria;


                categoriaNH.Nombre = categoria.Nombre;

                session.Update (categoriaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int New_ (CategoriaEN categoria)
{
        CategoriaNH categoriaNH = new CategoriaNH (categoria);

        try
        {
                SessionInitializeTransaction ();

                session.Save (categoriaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return categoriaNH.Id;
}

public void Modify (CategoriaEN categoria)
{
        try
        {
                SessionInitializeTransaction ();
                CategoriaNH categoriaNH = (CategoriaNH)session.Load (typeof(CategoriaNH), categoria.Id);

                categoriaNH.IdCategoria = categoria.IdCategoria;


                categoriaNH.Nombre = categoria.Nombre;

                session.Update (categoriaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                CategoriaNH categoriaNH = (CategoriaNH)session.Load (typeof(CategoriaNH), id);
                session.Delete (categoriaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

public System.Collections.Generic.IList<CategoriaEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<CategoriaEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(CategoriaNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<CategoriaEN>();
                else
                        result = session.CreateCriteria (typeof(CategoriaNH)).List<CategoriaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
