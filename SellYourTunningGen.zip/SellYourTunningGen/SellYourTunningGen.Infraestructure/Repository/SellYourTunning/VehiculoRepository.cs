
using System;
using System.Text;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;
using SellYourTunningGen.Infraestructure.EN.SellYourTunning;


/*
 * Clase Vehiculo:
 *
 */

namespace SellYourTunningGen.Infraestructure.Repository.SellYourTunning
{
public partial class VehiculoRepository : BasicRepository, IVehiculoRepository
{
public VehiculoRepository() : base ()
{
}


public VehiculoRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public VehiculoEN ReadOIDDefault (int id
                                  )
{
        VehiculoEN vehiculoEN = null;

        try
        {
                SessionInitializeTransaction ();
                vehiculoEN = (VehiculoEN)session.Get (typeof(VehiculoNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return vehiculoEN;
}

public System.Collections.Generic.IList<VehiculoEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<VehiculoEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(VehiculoNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<VehiculoEN>();
                        else
                                result = session.CreateCriteria (typeof(VehiculoNH)).List<VehiculoEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VehiculoRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (VehiculoEN vehiculo)
{
        try
        {
                SessionInitializeTransaction ();
                VehiculoNH vehiculoNH = (VehiculoNH)session.Load (typeof(VehiculoNH), vehiculo.Id);




                vehiculoNH.IdVehiculo = vehiculo.IdVehiculo;


                vehiculoNH.Marca = vehiculo.Marca;


                vehiculoNH.Attribute = vehiculo.Attribute;


                vehiculoNH.Modelo = vehiculo.Modelo;


                vehiculoNH.Anyo = vehiculo.Anyo;


                vehiculoNH.Kilometros = vehiculo.Kilometros;


                vehiculoNH.Descripcion = vehiculo.Descripcion;


                vehiculoNH.PrecioBase = vehiculo.PrecioBase;

                session.Update (vehiculoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VehiculoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public System.Collections.Generic.IList<VehiculoEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<VehiculoEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(VehiculoNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<VehiculoEN>();
                else
                        result = session.CreateCriteria (typeof(VehiculoNH)).List<VehiculoEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VehiculoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}

public int New_ (VehiculoEN vehiculo)
{
        VehiculoNH vehiculoNH = new VehiculoNH (vehiculo);

        try
        {
                SessionInitializeTransaction ();

                session.Save (vehiculoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VehiculoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return vehiculoNH.Id;
}

public void Modify (VehiculoEN vehiculo)
{
        try
        {
                SessionInitializeTransaction ();
                VehiculoNH vehiculoNH = (VehiculoNH)session.Load (typeof(VehiculoNH), vehiculo.Id);

                vehiculoNH.IdVehiculo = vehiculo.IdVehiculo;


                vehiculoNH.Marca = vehiculo.Marca;


                vehiculoNH.Attribute = vehiculo.Attribute;


                vehiculoNH.Modelo = vehiculo.Modelo;


                vehiculoNH.Anyo = vehiculo.Anyo;


                vehiculoNH.Kilometros = vehiculo.Kilometros;


                vehiculoNH.Descripcion = vehiculo.Descripcion;


                vehiculoNH.PrecioBase = vehiculo.PrecioBase;

                session.Update (vehiculoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VehiculoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                VehiculoNH vehiculoNH = (VehiculoNH)session.Load (typeof(VehiculoNH), id);
                session.Delete (vehiculoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VehiculoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

public System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> FiltrarAnyo (int ? p_anyo)
{
        System.Collections.Generic.IList<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM VehiculoNH self where FROM VehiculoNH v WHERE v.Anyo = :p_anyo";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("VehiculoNHfiltrarAnyoHQL");
                query.SetParameter ("p_anyo", p_anyo);

                result = query.List<SellYourTunningGen.ApplicationCore.EN.SellYourTunning.VehiculoEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in VehiculoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
