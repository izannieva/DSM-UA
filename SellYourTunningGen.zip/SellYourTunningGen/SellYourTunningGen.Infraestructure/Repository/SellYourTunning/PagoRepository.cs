
using System;
using System.Text;
using SellYourTunningGen.ApplicationCore.CEN.SellYourTunning;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
using SellYourTunningGen.ApplicationCore.Exceptions;
using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.ApplicationCore.CP.SellYourTunning;
using SellYourTunningGen.Infraestructure.EN.SellYourTunning;


/*
 * Clase Pago:
 *
 */

namespace SellYourTunningGen.Infraestructure.Repository.SellYourTunning
{
public partial class PagoRepository : BasicRepository, IPagoRepository
{
public PagoRepository() : base ()
{
}


public PagoRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public PagoEN ReadOIDDefault (int id
                              )
{
        PagoEN pagoEN = null;

        try
        {
                SessionInitializeTransaction ();
                pagoEN = (PagoEN)session.Get (typeof(PagoNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return pagoEN;
}

public System.Collections.Generic.IList<PagoEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<PagoEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(PagoNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<PagoEN>();
                        else
                                result = session.CreateCriteria (typeof(PagoNH)).List<PagoEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in PagoRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (PagoEN pago)
{
        try
        {
                SessionInitializeTransaction ();
                PagoNH pagoNH = (PagoNH)session.Load (typeof(PagoNH), pago.Id);

                pagoNH.Importe = pago.Importe;


                pagoNH.Metodo = pago.Metodo;


                pagoNH.Estado = pago.Estado;




                pagoNH.IdAnuncio = pago.IdAnuncio;

                session.Update (pagoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in PagoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public System.Collections.Generic.IList<PagoEN> Consultar (int first, int size)
{
        System.Collections.Generic.IList<PagoEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(PagoNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<PagoEN>();
                else
                        result = session.CreateCriteria (typeof(PagoNH)).List<PagoEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in PagoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}

public int New_ (PagoEN pago)
{
        PagoNH pagoNH = new PagoNH (pago);

        try
        {
                SessionInitializeTransaction ();

                session.Save (pagoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in PagoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return pagoNH.Id;
}

public void Modify (PagoEN pago)
{
        try
        {
                SessionInitializeTransaction ();
                PagoNH pagoNH = (PagoNH)session.Load (typeof(PagoNH), pago.Id);

                pagoNH.Importe = pago.Importe;


                pagoNH.Metodo = pago.Metodo;


                pagoNH.Estado = pago.Estado;


                pagoNH.IdAnuncio = pago.IdAnuncio;

                session.Update (pagoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in PagoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                PagoNH pagoNH = (PagoNH)session.Load (typeof(PagoNH), id);
                session.Delete (pagoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in PagoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

public System.Collections.Generic.IList<PagoEN> ReadAll (int first, int size)
{
        System.Collections.Generic.IList<PagoEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(PagoNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<PagoEN>();
                else
                        result = session.CreateCriteria (typeof(PagoNH)).List<PagoEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is SellYourTunningGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new SellYourTunningGen.ApplicationCore.Exceptions.DataLayerException ("Error in PagoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
