

using SellYourTunningGen.ApplicationCore.IRepository.SellYourTunning;
using SellYourTunningGen.Infraestructure.Repository.SellYourTunning;
using SellYourTunningGen.Infraestructure.CP;
using System;
using System.Collections.Generic;
using System.Text;

namespace SellYourTunningGen.Infraestructure.Repository
{
public class UnitOfWorkRepository : GenericUnitOfWorkRepository
{
SessionCPNHibernate session;


public UnitOfWorkRepository(SessionCPNHibernate session)
{
        this.session = session;
}

public override IUsuarioRepository UsuarioRepository {
        get
        {
                this.usuariorepository = new UsuarioRepository ();
                this.usuariorepository.setSessionCP (session);
                return this.usuariorepository;
        }
}

public override IMensajesRepository MensajesRepository {
        get
        {
                this.mensajesrepository = new MensajesRepository ();
                this.mensajesrepository.setSessionCP (session);
                return this.mensajesrepository;
        }
}

public override IAnunciosRepository AnunciosRepository {
        get
        {
                this.anunciosrepository = new AnunciosRepository ();
                this.anunciosrepository.setSessionCP (session);
                return this.anunciosrepository;
        }
}

public override IVehiculoRepository VehiculoRepository {
        get
        {
                this.vehiculorepository = new VehiculoRepository ();
                this.vehiculorepository.setSessionCP (session);
                return this.vehiculorepository;
        }
}

public override IVentaRepository VentaRepository {
        get
        {
                this.ventarepository = new VentaRepository ();
                this.ventarepository.setSessionCP (session);
                return this.ventarepository;
        }
}

public override ICategoriaRepository CategoriaRepository {
        get
        {
                this.categoriarepository = new CategoriaRepository ();
                this.categoriarepository.setSessionCP (session);
                return this.categoriarepository;
        }
}

public override IPagoRepository PagoRepository {
        get
        {
                this.pagorepository = new PagoRepository ();
                this.pagorepository.setSessionCP (session);
                return this.pagorepository;
        }
}
}
}

