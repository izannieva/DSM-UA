
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
namespace SellYourTunningGen.Infraestructure.EN.SellYourTunning
{
public partial class AnunciosNH : AnunciosEN {
public AnunciosNH ()
{
}

public AnunciosNH (AnunciosEN dto) : base (dto)
{
}
}
}
