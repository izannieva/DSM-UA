
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
namespace SellYourTunningGen.Infraestructure.EN.SellYourTunning
{
public partial class MensajesNH : MensajesEN {
public MensajesNH ()
{
}

public MensajesNH (MensajesEN dto) : base (dto)
{
}
}
}
