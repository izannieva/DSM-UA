
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
namespace SellYourTunningGen.Infraestructure.EN.SellYourTunning
{
public partial class UsuarioNH : UsuarioEN {
public UsuarioNH ()
{
}

public UsuarioNH (UsuarioEN dto) : base (dto)
{
}
}
}
