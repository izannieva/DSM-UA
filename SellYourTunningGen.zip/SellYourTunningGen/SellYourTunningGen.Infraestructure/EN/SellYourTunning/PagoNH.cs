
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
namespace SellYourTunningGen.Infraestructure.EN.SellYourTunning
{
public partial class PagoNH : PagoEN {
public PagoNH ()
{
}

public PagoNH (PagoEN dto) : base (dto)
{
}
}
}
