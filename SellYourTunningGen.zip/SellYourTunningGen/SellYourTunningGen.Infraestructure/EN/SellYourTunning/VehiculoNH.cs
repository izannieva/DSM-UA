
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
namespace SellYourTunningGen.Infraestructure.EN.SellYourTunning
{
public partial class VehiculoNH : VehiculoEN {
public VehiculoNH ()
{
}

public VehiculoNH (VehiculoEN dto) : base (dto)
{
}
}
}
