
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
namespace SellYourTunningGen.Infraestructure.EN.SellYourTunning
{
public partial class CategoriaNH : CategoriaEN {
public CategoriaNH ()
{
}

public CategoriaNH (CategoriaEN dto) : base (dto)
{
}
}
}
