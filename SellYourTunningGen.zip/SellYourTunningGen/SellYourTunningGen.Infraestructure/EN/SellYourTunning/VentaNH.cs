
using System;
using SellYourTunningGen.ApplicationCore.EN.SellYourTunning;
namespace SellYourTunningGen.Infraestructure.EN.SellYourTunning
{
public partial class VentaNH : VentaEN {
public VentaNH ()
{
}

public VentaNH (VentaEN dto) : base (dto)
{
}
}
}
